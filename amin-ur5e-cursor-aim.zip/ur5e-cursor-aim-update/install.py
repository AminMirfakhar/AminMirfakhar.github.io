#!/usr/bin/env python3
"""Safely patch the UR5e hero to use bounded cursor-driven TCP position and tool-Z aiming."""
from pathlib import Path
from datetime import datetime, timezone
import sys, subprocess, shutil, re

root = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if not (root/'_config.yml').is_file(): sys.exit('ERROR: Run from your Jekyll repository root (next to _config.yml).')
branch = subprocess.run(['git','branch','--show-current'],cwd=root,text=True,capture_output=True)
if branch.returncode or branch.stdout.strip()!='engineering-redesign': sys.exit('ERROR: Switch to engineering-redesign first; no files changed.')
js = root/'assets/js/am-ur5e-hero.js'
if not js.is_file(): sys.exit('ERROR: Cannot find assets/js/am-ur5e-hero.js. Install the UR5e mesh update first.')
src = js.read_text()
if 'AM_CURSOR_IK_V1' in src:
    print('Cursor tool-Z aiming update is already installed. Nothing changed.');sys.exit(0)
old_marker='  let mouseX=0,mouseY=0,hover=false;'
start=src.find(old_marker)
end=src.find('  window.addEventListener(\'pointermove\'', start)
if start<0 or end<0 or 'const tcp =' not in src or 'function setQ(' not in src:
    sys.exit('ERROR: The existing UR5e script is different from the expected mesh version. No changes made. Share the JS file for a tailored update.')
# Ensure known tail after pointermove; work even if prior tuning has been applied.
animate_start=src.find('  function animate(now)',end)
if animate_start<0:sys.exit('ERROR: Animation function not found. Nothing changed.')
interactive_start=src.find('    else{',animate_start)
interactive_end=src.find('\n    renderer.render(scene,camera);',interactive_start)
if interactive_start<0 or interactive_end<0:sys.exit('ERROR: Interactive section not recognized. Nothing changed.')
interactive_fragment=src[interactive_start:interactive_end]
if 'interactive=interactive.map' not in interactive_fragment or 'desired[0]' not in interactive_fragment:
    sys.exit('ERROR: Interactive section differs from known version. Nothing changed.')
settings="""// AM_CURSOR_IK_V1: Edit these settings to tune position and tool-Z aiming separately.
const CURSOR_IK_TUNING = {
  positionSensitivity: 0.10,    // TCP translation in meters, per normalized cursor movement (try 0.05–0.17)
  orientationSensitivity: 0.60, // Tool-Z tilt intensity (try 0.25–1.2)
  responseSpeed: 5.5,           // Higher = faster tracking (try 3–9)
  maxJointOffset: 0.85,         // Radians from initial idle pose, to limit extreme configurations
  solverIterations: 5,
  damping: 0.10,
  robotZoom: 1.12               // Camera zoom; does not change page width
};
"""
if 'const HERO_TUNING' in src:
    src=re.sub(r'// Adjust these values to customize the UR5e homepage animation\.[\s\S]*?const HERO_TUNING\s*=\s*\{[\s\S]*?\};\s*',settings+'\n',src,count=1)
else:
    i=src.find("const holder = document.querySelector")
    if i<0:sys.exit('ERROR: Holder selector missing; nothing changed.')
    src=src[:i]+settings+'\n'+src[i:]
# Resize camera according to tuning, without modifying overall website width.
src=src.replace('const aspect=w/h, hh=.70 / HERO_TUNING.robotZoom;', 'const aspect=w/h, hh=.70 / CURSOR_IK_TUNING.robotZoom;')
src=src.replace('const aspect=w/h, hh=.70;', 'const aspect=w/h, hh=.70 / CURSOR_IK_TUNING.robotZoom;')
# Inject accurate TCP and tool-Z observations and numerical bounded Jacobian solver.
functions=r'''  // AM_CURSOR_IK_V1: local +Z of the TCP is the direction the gripper should aim.
  const localZ = new THREE.Vector3(0,0,1);
  function tcpState(joints) {
    setQ(joints);
    scene.updateMatrixWorld(true);
    const p=new THREE.Vector3();
    const quat=new THREE.Quaternion();
    tcp.getWorldPosition(p); tcp.getWorldQuaternion(quat);
    return {p,z:localZ.clone().applyQuaternion(quat).normalize()};
  }
  // Gaussian elimination for a small damped 6x6 normal-equation system.
  function solve6(a,b) {
    const n=6,m=a.map((r,i)=>[...r,b[i]]);
    for(let i=0;i<n;i++) {
      let k=i;
      for(let j=i+1;j<n;j++) if(Math.abs(m[j][i])>Math.abs(m[k][i]))k=j;
      if(Math.abs(m[k][i])<1e-10)return new Array(6).fill(0);
      [m[i],m[k]]=[m[k],m[i]];
      const inv=1/m[i][i];
      for(let c=i;c<=n;c++)m[i][c]*=inv;
      for(let j=0;j<n;j++)if(j!==i) {
        const f=m[j][i];
        for(let c=i;c<=n;c++)m[j][c]-=f*m[i][c];
      }
    }
    return m.map(row=>row[n]);
  }
  const idleState=tcpState(rest);
  const idlePos=idleState.p.clone();
  const idleZ=idleState.z.clone();
  const cameraRight=new THREE.Vector3(1,0,0).applyQuaternion(camera.quaternion);
  const cameraUp=new THREE.Vector3(0,1,0).applyQuaternion(camera.quaternion);
  // The cursor lies on an imaginary plane normal to the *idle* tool Z axis;
  // thus center cursor preserves the original pointing direction.
  function desiredToolState(mx,my) {
    const px=mx*CURSOR_IK_TUNING.positionSensitivity;
    const py=-my*CURSOR_IK_TUNING.positionSensitivity;
    const pos=idlePos.clone().addScaledVector(cameraRight,px)
      .addScaledVector(cameraUp,py*.72);
    const aimPoint=idlePos.clone().addScaledVector(idleZ,.54)
      .addScaledVector(cameraRight,mx*.42*CURSOR_IK_TUNING.orientationSensitivity)
      .addScaledVector(cameraUp,-my*.34*CURSOR_IK_TUNING.orientationSensitivity);
    const axis=aimPoint.sub(pos).normalize();
    return {p:pos,z:axis};
  }
  const lower=[.6,.6,.6,1.05,1.05,1.25];
  function aimSolve(previous,target) {
    const angles=previous.slice(), step=.0006;
    const orientWeight=.65;
    for(let iteration=0;iteration<CURSOR_IK_TUNING.solverIterations;iteration++) {
      const state=tcpState(angles);
      const err=[
        (target.p.x-state.p.x), (target.p.y-state.p.y), (target.p.z-state.p.z),
        (target.z.x-state.z.x)*orientWeight,
        (target.z.y-state.z.y)*orientWeight,
        (target.z.z-state.z.z)*orientWeight
      ];
      const J=Array.from({length:6},()=>new Array(6).fill(0));
      for(let c=0;c<6;c++) {
        const perturbed=angles.slice();perturbed[c]+=step;
        const s=tcpState(perturbed);
        const dP=s.p.clone().sub(state.p).multiplyScalar(1/step);
        const dZ=s.z.clone().sub(state.z).multiplyScalar(orientWeight/step);
        [dP.x,dP.y,dP.z,dZ.x,dZ.y,dZ.z].forEach((v,r)=>J[r][c]=v);
      }
      const a=Array.from({length:6},()=>new Array(6).fill(0));
      const b=new Array(6).fill(0);
      for(let i=0;i<6;i++){
        for(let r=0;r<6;r++)b[i]+=J[r][i]*err[r];
        for(let k=0;k<6;k++){
          for(let r=0;r<6;r++)a[i][k]+=J[r][i]*J[r][k];
        }
        a[i][i]+=CURSOR_IK_TUNING.damping**2;
        // Gentle regularization against drifting far from the idle pose.
        b[i]-=.005*(angles[i]-rest[i]);
      }
      const dq=solve6(a,b);
      for(let i=0;i<6;i++){
        const d=THREE.MathUtils.clamp(dq[i],-.11,.11);
        const bound=Math.min(CURSOR_IK_TUNING.maxJointOffset,lower[i]);
        angles[i]=THREE.MathUtils.clamp(angles[i]+d,rest[i]-bound,rest[i]+bound);
      }
    }
    setQ(previous); // Prevent numerical probing from moving the visible robot mid-frame.
    return angles;
  }
'''
src=src.replace(old_marker,functions+old_marker,1)
src=src.replace('hover=e.clientY>=r.top&&e.clientY<=r.bottom;', 'hover=e.clientX>=r.left&&e.clientX<=r.right&&e.clientY>=r.top&&e.clientY<=r.bottom;')
# replace only the interactive else block with a solver; smooth response limits kinematic jumps.
interactive_start=src.find('    else{',src.find('  function animate(now)'))
interactive_end=src.find('\n    renderer.render(scene,camera);',interactive_start)
replacement='''    else {
      const tx=hover?mouseX:0,ty=hover?mouseY:0;
      const target=desiredToolState(tx,ty);
      const solved=aimSolve(interactive,target);
      const alpha=1-Math.exp(-delta*CURSOR_IK_TUNING.responseSpeed);
      interactive=interactive.map((v,i)=>v+(solved[i]-v)*alpha);
      setQ(interactive);
      cube.position.copy(placePoint);fingers(.039);
    }'''
src=src[:interactive_start]+replacement+src[interactive_end:]
# removal of previous full-hero width tweak is explicitly out of scope.
backup=root/'.am-cursor-ik-backups'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
backup.mkdir(parents=True,exist_ok=True)
shutil.copy2(js,backup/js.name)
js.write_text(src)
print('Updated:',js.relative_to(root))
print('Backup:',backup)
print('Only the UR5e JavaScript was modified; Projects page, About Me and navigation untouched.')
print('Restart Jekyll and hard-refresh your browser. Adjust CURSOR_IK_TUNING at top of JS.')
