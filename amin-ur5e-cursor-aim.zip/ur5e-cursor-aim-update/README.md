# UR5e cursor position + tool-Z aiming update

This update changes only `assets/js/am-ur5e-hero.js`. It does **not** change the Projects sidebar, About Me text, portrait, navigation, or width of the homepage. Designed for the `engineering-redesign` branch and for the existing **mesh-based UR5e** package.

## Installation in GitHub Codespaces

1. Download `amin-ur5e-cursor-aim.zip` and drag it to the **Explorer root** of your current Codespace, next to `_config.yml`.
2. In a terminal at the repository root, run:

```bash
python3 -m zipfile -e amin-ur5e-cursor-aim.zip /tmp/ur5e-cursor-aim
find /tmp/ur5e-cursor-aim -name install.py
python3 /tmp/ur5e-cursor-aim/ur5e-cursor-aim-update/install.py .
```

3. Restart your Jekyll server (activate the Python/Jupyter virtual environment if needed):

```bash
bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch
```

4. Open your private port-4000 preview and hard-refresh (Ctrl+Shift+R). After the 12-second pickup sequence, move your mouse around the robot canvas.

## Tunable parameters

Open `assets/js/am-ur5e-hero.js` and edit `CURSOR_IK_TUNING` at the beginning:

```js
const CURSOR_IK_TUNING = {
  positionSensitivity: 0.10,    // TCP displacement in meters per normalized cursor displacement
  orientationSensitivity: 0.60, // how far +Z tips toward the cursor
  responseSpeed: 5.5,           // motion smoothing, higher = faster response
  maxJointOffset: 0.85,         // safety bound relative to rest pose (radians)
  solverIterations: 5,
  damping: 0.10,
  robotZoom: 1.12
};
```

Try `positionSensitivity: 0.14` and `orientationSensitivity: 1.0` for stronger movement. `responseSpeed: 7` tracks more quickly. Keep `maxJointOffset` below about `1.0` for an initial visual test.

## How the aiming works

The code computes the TCP's **world-space local +Z axis** from the wrist and tool hierarchy. A cursor position becomes a point on a virtual plane in front of the gripper's *resting* +Z axis. A damped, numerically estimated Jacobian moves the robot joints toward both a position target and a direction target. This is a **visual interactive kinematics approximation**, not calibrated real-robot inverse kinematics, collision detection, or exact screen-space ray-intersection targeting. Joint bounds and damping may prevent perfect alignment at extreme cursor positions. The robot does not track until after the intro pick-and-place sequence.

## If you need to undo it

The installer backs up the original JS under `.am-cursor-ik-backups/<timestamp>/am-ur5e-hero.js`. Restore that file to `assets/js/am-ur5e-hero.js` and refresh. Do not commit the backup folder or the ZIP archive.

The installer refuses to run on branches other than `engineering-redesign` and on versions it cannot identify. If it refuses, provide your current `assets/js/am-ur5e-hero.js` for a tailored patch rather than forcing it.
