# Sidebar filters and navbar cleanup — Engineering Portfolio

This patch updates the existing Jekyll/al-folio engineering portfolio. It keeps **12 unique projects**, preserves project detail pages and professional type badges, and replaces large button filters with a left **checkbox sidebar**.

## Changes

- Expandable **Technical Disciplines** and **Project Type** sections, each with counts and checkboxes
- **Clear Filters** inside the sidebar
- Search for projects in the content column (not the global navbar search)
- Multiple selections: OR within each group, AND between the two groups; projects shown once
- Keeps only the existing al-folio navbar theme toggle and removes extra page-specific theme controls
- Sets `search_enabled: false` in `_config.yml` to remove the site-wide Ctrl+K navbar search; **does not disable the separate bibliography search setting**
- Mobile responsive: sidebar stacks above cards on narrow screens

## Install on `engineering-redesign` only

Upload `amin-sidebar-filter-update.zip` to the *repository root* in Codespaces (where `_config.yml` is), then run:

```bash
python3 -m zipfile -e amin-sidebar-filter-update.zip /tmp/amin-sidebar-filter-update
python3 /tmp/amin-sidebar-filter-update/install.py .
```

The installer refuses to edit branches other than `engineering-redesign`. It backs up replaced files to a timestamped folder under `/tmp`, copies the 12 project pages and supporting files, removes only the redundant local theme control from our earlier package, and changes **only the `search_enabled` setting** in the existing `_config.yml`.

Then stop the preview server with Ctrl+C and run:

```bash
bundle exec jekyll clean
bundle exec jekyll build
bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch
```

In the private port 4000 preview, open `/projects/`. Test checkbox selections, Clear Filters, project search and project detail URLs; verify the top navbar theme toggle, and confirm Ctrl+K icon is gone.

Verification in another terminal:

```bash
grep -o 'data-project-card' _site/projects/index.html | wc -l
# Expected: 12
grep -n 'search_enabled:' _config.yml
# Expected: search_enabled: false
```

Note: The previous repair package could have left old `_pages/projects/*.md` pages in your repository. This patch updates the expected twelve but does not delete unrelated pages. Do not commit `.venv`, `vendor/bundle`, ZIP archives or generated `_site` files. Review `git diff` before committing.

Do not merge `main` until the private preview looks right.
