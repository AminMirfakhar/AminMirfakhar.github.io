#!/usr/bin/env python3
"""Install sidebar filters onto engineering-redesign; preserve other site files."""
from pathlib import Path
import datetime, re, shutil, subprocess, sys
root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
src = Path(__file__).resolve().parent
if not (root / '_config.yml').is_file():
    sys.exit('ERROR: run at the Jekyll repository root alongside _config.yml')
branch = subprocess.run(['git','branch','--show-current'],cwd=root,capture_output=True,text=True,check=True).stdout.strip()
if branch != 'engineering-redesign':
    sys.exit(f'ERROR: expected engineering-redesign branch, got {branch!r}. No changes made.')
files = [p for folder in ('_data','_pages','_includes','assets') for p in (src/folder).rglob('*') if p.is_file()]
backup = Path('/tmp') / ('amin-sidebar-backup-' + datetime.datetime.now().strftime('%Y%m%d-%H%M%S-%f'))
def save(path):
    if path.is_file():
        dest = backup / path.relative_to(root)
        dest.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(path,dest)
for p in files:
    target=root/p.relative_to(src)
    save(target)
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(p,target)
# Old toolbar introduced by our previous package: remove its duplicate script/partial.
for rel in ('_includes/am-theme-control.html','assets/js/am-theme-control.js'):
    path=root/rel
    if path.exists():
        save(path)
        path.unlink()
# Navbar Ctrl+K search is controlled by al-folio's config, separate from project search.
config=root/'_config.yml'
source=config.read_text()
pattern=re.compile(r'(?m)^([ \t]*search_enabled[ \t]*:[ \t]*)(?:true|false)([ \t]*(?:#.*)?)$')
if pattern.search(source):
    updated=pattern.sub(r'\g<1>false\g<2>',source,count=1)
else:
    updated=source.rstrip()+'\nsearch_enabled: false\n'
if updated!=source:
    save(config)
    config.write_text(updated)
print('Installed',len(files),'project/site files')
print('Disabled site-wide Ctrl+K search in _config.yml; project search remains available')
print('Removed old per-page theme controls; original navbar theme switcher retained')
print('Backup of replaced files:',backup)
print('Check _pages/projects.md, then run bundle exec jekyll build (do not merge main yet).')
