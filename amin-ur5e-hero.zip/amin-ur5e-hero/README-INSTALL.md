# UR5e-inspired solid robot — home hero add-on

This is a *non-destructive add-on* for the existing engineering-redesign Jekyll site. It does not replace the homepage, About Me content, profile image, projects, publications, navigation, or site configuration.

## Included

- `_includes/am-ur5e-hero.html` — HTML wrapper and linked assets
- `assets/css/am-ur5e-hero.css` — background layer, responsiveness, theme support
- `assets/js/am-ur5e-hero.js` — procedural 6-joint solid robot, orange cube, pick/carry/place, subtle pointer idle
- `install.py` — installer, creates backups of replaced files in `.am-hero-backups/`

The 3D scene uses Three.js **0.160.1** loaded from `cdn.jsdelivr.net`. GitHub Pages hosts your own script, but visitors require internet access to retrieve the Three.js module. If it fails to load, the hero still works and a subtle static fallback remains. No copyrighted UR5e manufacturer CAD mesh is distributed. The robot is a **UR5e-inspired illustrative approximation**, not a dimensional-accuracy or collision-checked simulator. Motion is six-joint, scripted pose interpolation; interactive mode uses small joint offsets, not true inverse-kinematics TCP target tracking.

## Installation in Codespaces

1. Commit or safely save any important work before installation.
2. Confirm branch: `git branch --show-current` must print `engineering-redesign`.
3. Upload `amin-ur5e-hero.zip` into the **repository root** (next to `_config.yml`).
4. In terminal:

```bash
python3 -m zipfile -e amin-ur5e-hero.zip /tmp/amin-ur5e-unpacked
find /tmp/amin-ur5e-unpacked -name install.py -print
python3 /tmp/amin-ur5e-unpacked/amin-ur5e-hero/install.py .
```

The ZIP contains a single top-level `amin-ur5e-hero/` folder; the installer is at the exact path shown above. You can also `cd` into the extracted folder and run `python3 install.py /workspaces/AminMirfakhar.github.io`.

5. Restart Jekyll (Ctrl+C first if the server runs):

```bash
bundle exec jekyll clean
bundle exec jekyll build
bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch
```

6. In Ports, open private port 4000. Hard-refresh the homepage. The robot should move through a pick-and-place sequence (about 13 seconds) and then react *subtly* to pointer movement over the hero.
7. Check About Me text, portrait, navbar theme button, Projects sidebar, and publication links remain intact.

## If something is wrong

- The Jekyll build must succeed first. If the hero is empty, open the browser Developer Tools console and check whether `cdn.jsdelivr.net`/WebGL is blocked.
- Reduced Motion preferences skip the animation and show the final pose.
- On touch-only devices, the robot doesn't follow a cursor; the intro animation still plays.
- Run `git diff -- _pages/about.md` to inspect the small addition.
- To remove the add-on before commit, restore the saved `_pages/about.md` from `.am-hero-backups/<timestamp>/_pages/about.md` and delete the three added files. Or, if you made no other changes, use Git's selective restore for those paths.
- Do **not** merge to `main` until previewed. Existing GitHub Pages source stays unchanged.

## Notes

- The hero's existing profile photo stays opaque, and the model is placed behind the hero layout. A screen recording or screenshot of the homepage can help fine-tune the camera and robot placement for your actual content.
- This animation is illustrative, not a verified UR5e motion plan. To upgrade to a *true* UR5e model and constrained TCP IK, a licensed/redistributable UR5e mesh plus kinematic parameters and a collision-aware solution would be appropriate.
