#!/usr/bin/env python3
"""Safe and repeatable hero-only installer for Amin's engineering-redesign Jekyll branch."""
from pathlib import Path
from datetime import datetime, timezone
import shutil, subprocess, sys, re

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
src = Path(__file__).resolve().parent
page = root / '_pages' / 'about.md'
if not (root / '_config.yml').is_file() or not page.is_file():
    sys.exit('ERROR: run this at the repository root, with _config.yml and _pages/about.md')
try:
    branch = subprocess.check_output(['git','branch','--show-current'], cwd=root, text=True).strip()
except (OSError, subprocess.CalledProcessError):
    sys.exit('ERROR: could not determine git branch.')
if branch != 'engineering-redesign':
    sys.exit(f'ERROR: current branch is {branch!r}, not engineering-redesign. Nothing changed.')
original = page.read_text(encoding='utf-8')
if 'am-ur5e-hero.html' in original:
    print('Hero include already present; updating only add-on assets.')
    newpage = original
else:
    pat = re.compile(r'(<section\s+class="[^"]*\bam-hero\b[^"]*"[^>]*>)', flags=re.I)
    match = pat.search(original)
    if not match:
        sys.exit('ERROR: Could not find <section class="am-hero"> in _pages/about.md. Nothing changed. Send the current about.md so we can adapt the installer.')
    old_open = match.group(1)
    new_open = old_open.replace('class="', 'class="am-robot-hero ', 1)
    newpage = original[:match.start()] + new_open + "\n    {% include am-ur5e-hero.html %}\n" + original[match.end():]
    if '{% include am-ur5e-hero.html %}' not in newpage:
        sys.exit('ERROR: include insertion failed')

backup = root / '.am-hero-backups' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
files = [Path('_includes/am-ur5e-hero.html'), Path('assets/css/am-ur5e-hero.css'), Path('assets/js/am-ur5e-hero.js')]
for rel in [Path('_pages/about.md'), *files]:
    target = root / rel
    if target.is_file():
        archive = backup / rel
        archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, archive)
for rel in files:
    target = root / rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src / rel, target)
if newpage != original:
    page.write_text(newpage,encoding='utf-8')
print('Installed solid 6-axis robot hero add-on.')
print('Modified _pages/about.md minimally; did NOT modify the projects, navbar, publication files, or Jekyll config.')
print('Backup of replaced files:', backup)
print('Next: bundle exec jekyll build; then bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch')
