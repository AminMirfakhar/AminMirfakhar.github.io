# UR5e hero: wider layout + stronger cursor response

This small **patch** changes only the existing UR5e hero CSS/JS and removes an obsolete page-level theme button include. It does **not** overwrite `_pages/projects.md`, project filters, detail pages, or your navbar.

## Install on `engineering-redesign`

Upload `amin-ur5e-tuning-update.zip` via the Codespaces Explorer to the same directory as `_config.yml`. Then:

```bash
python3 -m zipfile -e amin-ur5e-tuning-update.zip /tmp/am-ur5e-tuning
python3 /tmp/am-ur5e-tuning/amin-ur5e-tuning-update/install.py .
```

The installer checks your branch, avoids applying twice, and backs up changed files in `.am-hero-tuning-backups/`. If your hero script is different from the version installed previously, the installer stops rather than overwriting it.

Restart Jekyll (`Ctrl+C` in the running terminal) and then run:

```bash
bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch
```

If your site requires Jupyter, activate your Python virtual environment first. Refresh the page with Ctrl+Shift+R. Don't merge into `main` yet.

## Customize motion yourself

Edit `assets/js/am-ur5e-hero.js`, near the top:

```js
const HERO_TUNING = {
  cursorIntensity: 2.5,
  responseSpeed: 5.5,
  robotZoom: 1.12
};
```

- `cursorIntensity`: multiplier for mouse-driven joint changes. `1` matches the earlier subtle behavior; `2`–`3` is more noticeable. Avoid excessive values that cause implausible motion or clipping.
- `responseSpeed`: higher value tracks the cursor more quickly; lower value is floatier.
- `robotZoom`: `1.12` makes the robot about 12% larger; `1` restores prior framing. This is camera zoom, not true 3D model scaling.

To change the desktop hero width, edit `assets/css/am-ur5e-hero.css` under `/* AM HERO WIDTH TUNING */`: `1460px` is the upper limit and `48px` is the combined viewport margin. The portrait and hero text are preserved. Mobile sizing is unchanged.

The extra page-level `{% include am-theme-control.html %}` is removed from `_pages/*.md`, where present. The existing navbar theme button is **not** touched. Old unused theme-control files can remain unreferenced.
