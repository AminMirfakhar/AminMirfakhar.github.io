#!/usr/bin/env python3
"""Tune the existing UR5e homepage and remove duplicate per-page theme controls.
Does not overwrite project filters, project pages or navigation.
"""
from pathlib import Path
from datetime import datetime, timezone
import sys, subprocess, re, shutil

root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
if not (root/'_config.yml').exists(): sys.exit('ERROR: Run in Jekyll repo root next to _config.yml')
branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()
if branch!='engineering-redesign':sys.exit(f'ERROR: Expected engineering-redesign, got {branch!r}.')
js=root/'assets/js/am-ur5e-hero.js'
css=root/'assets/css/am-ur5e-hero.css'
if not js.exists() or not css.exists():sys.exit('ERROR: Existing UR5e files not found. Install UR5e Mesh package first.')
original_js=js.read_text()
if 'desired[0]+=.095*tx' not in original_js and 'HERO_TUNING' not in original_js:
    sys.exit('ERROR: UR5e script differs from the known version. Nothing modified; share script for a tailored patch.')
backup=root/'.am-hero-tuning-backups'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
changes={}
if 'HERO_TUNING' not in original_js:
    new_js=original_js.replace("const holder = document.querySelector('[data-am-robot-canvas]');", """// Adjust these values to customize the UR5e homepage animation.
// Bigger values cause more noticeable motion after pick-and-place.
const HERO_TUNING = {
  cursorIntensity: 2.5, // 1 = original subtle motion; 2.5 = stronger; 3.5 = quite strong
  responseSpeed: 5.5,   // 3.4 = original gentle response; 6-8 = quicker tracking
  robotZoom: 1.12       // 1 = previous size; 1.12 = 12% larger robot
};

const holder = document.querySelector('[data-am-robot-canvas]');""")
    new_js=new_js.replace('const aspect=w/h, hh=.70;', 'const aspect=w/h, hh=.70 / HERO_TUNING.robotZoom;')
    new_js=new_js.replace('desired[0]+=.095*tx;desired[1]+=.045*ty;desired[2]-=.04*ty;','desired[0]+=.095*tx*HERO_TUNING.cursorIntensity;desired[1]+=.045*ty*HERO_TUNING.cursorIntensity;desired[2]-=.04*ty*HERO_TUNING.cursorIntensity;')
    new_js=new_js.replace('desired[3]+=.035*ty;desired[4]+=.085*tx;desired[5]+=.065*tx;','desired[3]+=.035*ty*HERO_TUNING.cursorIntensity;desired[4]+=.085*tx*HERO_TUNING.cursorIntensity;desired[5]+=.065*tx*HERO_TUNING.cursorIntensity;')
    new_js=new_js.replace('Math.exp(-delta*3.4)', 'Math.exp(-delta*HERO_TUNING.responseSpeed)')
    if 'HERO_TUNING.cursorIntensity' not in new_js or 'HERO_TUNING.responseSpeed)' not in new_js:sys.exit('ERROR: Failed to patch sensitivity safely')
    changes[js]=new_js
original_css=css.read_text()
if '/* AM HERO WIDTH TUNING */' not in original_css:
    changes[css]=original_css+"""

/* AM HERO WIDTH TUNING */
/* Extends hero beyond al-folio's narrow content column on desktops. */
@media (min-width: 900px) {
  .am-site .am-hero.am-robot-hero {
    width: min(1460px, calc(100vw - 48px));
    max-width: none;
    margin-left: 50%;
    transform: translateX(-50%);
    padding-left: clamp(20px, 3vw, 52px);
    padding-right: clamp(20px, 3vw, 52px);
    grid-template-columns: minmax(0, 1.1fr) minmax(300px, .75fr);
  }
}
"""
# Remove obsolete page-level theme widget added by earlier packages only.
removed=0
for page in (root/'_pages').rglob('*.md'):
    content=page.read_text()
    newer=re.sub(r'(?m)^\s*\{%\s*include\s+am-theme-control\.html\s*%\}\s*\n?', '', content)
    newer=re.sub(r'(?m)^\s*<script[^>]+am-theme-control\.js[^>]*></script>\s*\n?', '', newer)
    if newer!=content:
        changes[page]=newer
        removed+=1
if not changes: print('Nothing to change: tuning already installed.');sys.exit(0)
for path,newcontent in changes.items():
    original=path.read_bytes()
    b=backup/path.relative_to(root);b.parent.mkdir(parents=True,exist_ok=True)
    b.write_bytes(original)
    path.write_text(newcontent)
print('Updated:',len(changes),'files. Removed duplicate theme control from',removed,'page(s).')
print('Backup:',backup)
print('Do not commit .am-hero-tuning-backups. Restart Jekyll and refresh browser.')
