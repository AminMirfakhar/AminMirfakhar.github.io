# UR5e real-mesh hero + project sidebar restore

This package **replaces the UR5e approximation** and restores the exact checkbox-sidebar projects layout from the user's uploaded `amin-sidebar-filter-update(1).zip`.

## What this is
- A browser-rendered UR5e using **20 actual visual OBJ submeshes** from the open-source MuJoCo Menagerie UR5e model, derived from Universal Robots' URDF. Unlike the previous version, the robot links are **not procedural cylinders**.
- A six-joint scene graph using the link transforms from the UR5e MJCF source, with the end-effector attached at the model's `attachment_site` frame.
- A compact **generic two-finger gripper** (the gripper itself is not an official UR mesh), cube pickup/transfer/release, and small mouse-responsive wrist/joint motions after the intro.
- No pedestal or added stand. The actual robot base mesh remains, because a UR5e physically has a mounting base.
- Full 12-project sidebar catalog, category and type checkbox filters, Clear Filters, project detail pages, and matching existing sidebar CSS.

**Limitations:** The motion is joint-keyframed and visually synchronized to the cube, not collision-checked IK or a physically verified pick-and-place program. The two-finger gripper is custom, not a manufacturer CAD gripper. This package was syntax/structure tested locally, but **not browser-rendered against the user's live Codespace**. The visual OBJ meshes are downloaded by the installer (network access needed). Three.js and OBJLoader are loaded from jsDelivr at runtime (browser network needed).

## Installation: preserve your main branch
1. Open Codespaces on `engineering-redesign` and **commit any local edits you want to preserve** first. Keep `main` untouched.
2. Drag `amin-ur5e-mesh-sidebar.zip` into the **Codespaces Explorer**, repository root beside `_config.yml`.
3. Confirm the file is there: `ls -lh amin-ur5e-mesh-sidebar.zip`.
4. Extract and find the installer:

```bash
python3 -m zipfile -e amin-ur5e-mesh-sidebar.zip /tmp/amin-mesh-package
find /tmp/amin-mesh-package -name install.py
```

5. Run the printed installer path, typically:

```bash
python3 /tmp/amin-mesh-package/ur5e_mesh_sidebar_v2/install.py .
```

6. The installer first downloads 20 OBJ meshes and the upstream license; if a download fails, it does not change site files. It verifies your branch, preserves `_pages/about.md` except for ensuring the hero include is present, and restores the Projects sidebar assets. Replaced files are saved under `.am-mesh-backups/` (do **not** commit that backup directory).
7. With Jupyter available in your active virtual environment, run:

```bash
bundle exec jekyll clean
bundle exec jekyll build
bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch
```

8. Open port 4000 in Codespaces, inspect `/` for the UR5e and `/projects/` for the filters. Check `/projects/hexapod/` and `/projects/parallel-robot/`.
9. Use `git status` to review changes; leave your repository on `engineering-redesign`. Don't merge until you've visually verified the result.

## Mesh source and license
- MuJoCo Menagerie UR5e: https://github.com/google-deepmind/mujoco_menagerie/tree/main/universal_robots_ur5e
- Universal Robots ROS 2 Description: https://github.com/UniversalRobots/Universal_Robots_ROS2_Description
- Upstream assets and LICENSE are downloaded during installation and stored in `assets/models/ur5e/`.

## If the model is blank
Check browser DevTools Console and Network for missing OBJ files or blocked CDN imports. Verify mesh count with `find assets/models/ur5e -name '*.obj' | wc -l` — it should print `20`. Do **not** reinstate the procedural fallback; send console errors for targeted debugging.

## Undo
Review or restore files from `.am-mesh-backups/<timestamp>/`, or use `git restore` on the uncommitted changes. All edits are local to `engineering-redesign`.
