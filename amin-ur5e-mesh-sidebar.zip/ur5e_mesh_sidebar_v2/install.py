#!/usr/bin/env python3
"""Safely install UR5e real-mesh homepage and restore checkbox-sidebar projects.
Downloads upstream BSD-licensed UR5e visual OBJ assets at install time.
"""
from pathlib import Path
from datetime import datetime, timezone
import urllib.request, subprocess, shutil, sys, re

root = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
src = Path(__file__).resolve().parent
if not (root/'_config.yml').exists() or not (root/'_pages/about.md').exists():
    sys.exit('ERROR: Run from your Jekyll repository root next to _config.yml.')
try:
    branch=subprocess.check_output(['git','branch','--show-current'],cwd=root,text=True).strip()
except Exception:
    sys.exit('ERROR: Could not read current Git branch.')
if branch!='engineering-redesign':sys.exit(f'ERROR: branch is {branch!r}; expected engineering-redesign. Nothing changed.')

# Fetch *before* changing source files: missing meshes must never silently produce a fake robot.
mesh_names='''base_0 base_1 shoulder_0 shoulder_1 shoulder_2 upperarm_0 upperarm_1 upperarm_2 upperarm_3 forearm_0 forearm_1 forearm_2 forearm_3 wrist1_0 wrist1_1 wrist1_2 wrist2_0 wrist2_1 wrist2_2 wrist3'''.split()
mesh_dir=root/'assets/models/ur5e'
stage=Path('/tmp/amin-ur5e-mesh-stage')
stage.mkdir(parents=True,exist_ok=True)
source_url='https://raw.githubusercontent.com/google-deepmind/mujoco_menagerie/main/universal_robots_ur5e/'
missing=[]
for name in mesh_names:
    target=mesh_dir/(name+'.obj')
    if target.exists() and target.stat().st_size>200:continue
    missing.append((name,target))
if missing:
    print(f'Downloading {len(missing)} authentic UR5e OBJ meshes (internet required in Codespaces)...',flush=True)
    for name,target in missing:
        url=source_url+'assets/'+name+'.obj'
        try:
            request=urllib.request.Request(url,headers={'User-Agent':'Amin-UR5e-Jekyll-installer/2.0'})
            with urllib.request.urlopen(request,timeout=35) as req:
                contents=req.read()
            if len(contents)<200 or b'\nv ' not in b'\n'+contents[:5000]:
                raise ValueError('File does not look like a valid OBJ mesh')
            (stage/(name+'.obj')).write_bytes(contents)
            print('  OK',name,len(contents),'bytes',flush=True)
        except Exception as e:
            sys.exit(f'ERROR downloading {url}: {e}\nNo site files have been changed. Check Codespaces internet connection.')
    try:
        request=urllib.request.Request(source_url+'LICENSE',headers={'User-Agent':'Amin-UR5e-Jekyll-installer/2.0'})
        with urllib.request.urlopen(request,timeout=35) as response:
            (stage/'LICENSE-upstream.txt').write_bytes(response.read())
    except Exception as e:
        sys.exit(f'ERROR downloading upstream license: {e}. No site files changed.')
else:print('All 20 UR5e meshes already present.')

page=root/'_pages/about.md'
original=page.read_text(encoding='utf-8')
if 'am-ur5e-hero.html' in original:
    newpage=original
else:
    hit=re.search(r'(<section\s+class="[^"]*\bam-hero\b[^"]*"[^>]*>)',original,re.I)
    if not hit:
        sys.exit('ERROR: Could not find the existing <section class="am-hero"> in _pages/about.md. No site files changed.')
    opening=hit.group(1)
    if 'am-robot-hero' not in opening:opening=opening.replace('class="','class="am-robot-hero ',1)
    newpage=original[:hit.start()]+opening+'\n    {% include am-ur5e-hero.html %}\n'+original[hit.end():]

# Exclude about.md from the sidebar restore; it must retain the current portrait and bio.
files=[p for p in src.rglob('*') if p.is_file() and p.name not in ('install.py','README.md') and p.relative_to(src).as_posix()!='_pages/about.md']
backup=root/'.am-mesh-backups'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
for rel in [Path('_pages/about.md'),*[p.relative_to(src) for p in files]]:
    target=root/rel
    if target.is_file():
        outfile=backup/rel;outfile.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(target,outfile)
for file in files:
    rel=file.relative_to(src); target=root/rel
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(file,target)
page.write_text(newpage,encoding='utf-8')
mesh_dir.mkdir(parents=True,exist_ok=True)
for name,target in missing:shutil.copy2(stage/(name+'.obj'),target)
if (stage/'LICENSE-upstream.txt').exists():shutil.copy2(stage/'LICENSE-upstream.txt',mesh_dir/'LICENSE-upstream.txt')
(root/'assets/models/ur5e/SOURCE.txt').write_text('Source: https://github.com/google-deepmind/mujoco_menagerie/tree/main/universal_robots_ur5e\nUR5e description/visual meshes derived from Universal Robots URDF. See LICENSE-upstream.txt.\n',encoding='utf-8')
print('\nInstalled. Homepage content preserved; all 12 sidebar projects restored.\nBackups:',backup)
print('Next: activate Jupyter venv, run bundle exec jekyll build and serve on port 4000. Do not commit .am-mesh-backups or ZIP.')
