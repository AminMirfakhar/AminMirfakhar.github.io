# AXISPRO Racing Simulator Page — Update

This update is based on your uploaded `AminMirfakhar.github.io-engineering-redesign.zip` and changes **only** the Racing Car Motion Simulator individual page. All other project pages, the directory sidebar, About Me, and the UR5e animation remain untouched.

## Install in Codespaces

Upload `amin-axispro-racing-page-update.zip` to the repository root and run:

```bash
python3 -m zipfile -e amin-axispro-racing-page-update.zip /tmp/axispro-update
python3 /tmp/axispro-update/axispro-page-update/install.py .
```

Then restart Jekyll with your Python venv activated:

```bash
source ~/website-venv/bin/activate
bundle exec jekyll serve --host 0.0.0.0 --port 4000 --no-watch
```

Visit `/projects/racing-simulator/` and hard-refresh.

The hero uses the existing files `assets/img/projects/Racing Hexapod/AXISPRO-5.png` and `Racing.jpg`. Clicking a gallery thumbnail switches the background. To update media later, edit `_includes/am-racing-simulator-detail.html`. Page-only CSS lives in `assets/css/am-racing-simulator-detail.css`.

Content focuses on your kinematic/dynamic modeling, MATLAB optimization with collision considerations, sizing and actuation choices, SolidWorks, quality oversight, **and hands-on assembly work**. No new performance metrics were invented.

To commit to `engineering-redesign` (not `main`):

```bash
git add _pages/projects/racing-simulator.md _includes/am-racing-simulator-detail.html assets/css/am-racing-simulator-detail.css assets/js/am-racing-simulator-detail.js
git commit -m "Build AXISPRO racing simulator technical project page"
git push origin engineering-redesign
```
