(()=>{
  const root=document.querySelector('[data-am-racing]');
  if(!root)return;
  const backdrop=root.querySelector('[data-am-racing-backdrop]');
  const caption=root.querySelector('[data-am-racing-caption]');
  const buttons=[...root.querySelectorAll('[data-racing-image]')];
  buttons.forEach(button=>button.addEventListener('click',()=>{
    const image=button.getAttribute('data-racing-image');
    if(!image||!backdrop)return;
    backdrop.style.backgroundImage=`url(${JSON.stringify(image)})`;
    if(caption)caption.textContent=button.getAttribute('data-racing-label')||'';
    buttons.forEach(b=>{const selected=b===button;b.classList.toggle('is-active',selected);b.setAttribute('aria-pressed',String(selected));});
  }));
})();
