#!/usr/bin/env python3
"""Apply the AXISPRO detail-page update without changing the other 11 projects."""
from pathlib import Path
from shutil import copy2
import sys
source=Path(__file__).resolve().parent
repo=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
required=[repo/'_pages/projects/racing-simulator.md',repo/'assets/img/projects/Racing Hexapod/AXISPRO-5.png',repo/'assets/img/projects/Racing Hexapod/Racing.jpg']
missing=[str(p) for p in required if not p.is_file()]
if missing:
    sys.exit('Missing expected project files; run from the repository root.\n'+'\n'.join(missing))
for name in ['_pages/projects/racing-simulator.md','_includes/am-racing-simulator-detail.html','assets/css/am-racing-simulator-detail.css','assets/js/am-racing-simulator-detail.js']:
    target=repo/name
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():
        backup=target.with_name(target.name+'.pre-axispro.bak')
        if not backup.exists():copy2(target,backup)
    copy2(source/name,target)
    print('Updated:',name)
print('Done. Only the Racing Car Motion Simulator detail page has been updated.')
